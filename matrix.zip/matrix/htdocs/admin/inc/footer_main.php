<!-- Javascripts -->
<script src="../../assets/plugins/jquery/jquery-3.4.1.min.js"></script>
<script src="https://unpkg.com/@popperjs/core@2"></script>
<script src="../../assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="https://unpkg.com/feather-icons"></script>
<script src="../../assets/plugins/perfectscroll/perfect-scrollbar.min.js"></script>
<script src="../../assets/plugins/pace/pace.min.js"></script>
<script src="../../assets/plugins/jquery.toast/jquery.toast.js"></script>
<script src="../../assets/plugins/sweetalert/sweetalert2@8"></script>
<?php
foreach ($customJAVA as $java) {
    echo $java . "\n";
} ?>
<script src="../../assets/js/main.min.js"></script>
</body>

</html>